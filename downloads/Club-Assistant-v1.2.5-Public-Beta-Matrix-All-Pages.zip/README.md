# Club Assistant — v1.2.5 Public Beta

## v1.2.5 Theme System
- Primary and Secondary color controls now immediately change the dashboard and Chess.com sidebar.
- Eight one-click theme presets are included: Chess Classic, Gold & Black, Blue & White, Crimson & Black, Emerald, Royal Purple, Ocean, and Sunset.
- Presets are starting points; club owners can customize either color afterward.
- A live preview shows the selected colors before saving.
- Theme choices persist in settings and load automatically whenever Club Assistant opens.

A customizable Chrome extension for Chess.com club owners.

## v1.2.3 highlights
- Neutral public distribution with no preloaded club, member, link, affiliate, or organization-specific configuration.
- First-run club setup and configurable club identity.
- Custom logo, primary color, accent color, slogan/signature, links, and growth target.
- Multiple managed clubs and selectable home/message clubs.
- Member club assignments now populate from the owner’s managed-club list.
- Full local backup export and restore.
- Updated version labeling and neutral product presentation.

## Install
1. Extract this ZIP.
2. Open `chrome://extensions`.
3. Enable **Developer mode**.
4. Select **Load unpacked** and choose the extracted folder.

All operational data remains in Chrome local extension storage unless the user exports a backup.

- First-time sidebar users are directed into the guided dashboard setup.
- Dashboard controls return users to Chess.com and reopen the companion sidebar.
- Sidebar template dock can preview and load saved or built-in message templates.
- Added animated onboarding, module transitions, interactive card motion, and navigation effects across the main pages and sidebar.
- Lady Justice copyright branding remains permanent and unchanged.


## v1.2.3 Usability Update
- Added contextual quick guides to every dashboard module.
- Added an in-app workflow help dialog and keyboard-accessible controls.
- Improved focus states, form clarity, status feedback, and first-use guidance.
- Corrected visible version labels across the extension.