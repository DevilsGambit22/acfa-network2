const DEFAULT_SETTINGS = {
  setupComplete: false,
  clubName: "",
  clubUrl: "",
  websiteUrl: "",
  discordUrl: "",
  twitchUrl: "",
  affiliateCode: "",
  signupUrl: "",
  upgradeUrl: "",
  defaultSignature: "Every Player Belongs • Every Move Matters.",
  memberGoal: 250,
  animationMode: "cinematic",
  homeClubSlug: "",
  messageClubSlug: "",
  defaultMessageType: "announcement",
  primaryColor: "#262522",
  accentColor: "#81b64c",
  customLogoData: ""
};

const OWNER_EDITION_MIGRATION_KEY = "clubAssistantOwnerEditionV1Migrated";

export async function migrateClubOwnerEdition() {
  const state = await chrome.storage.local.get([OWNER_EDITION_MIGRATION_KEY, "managedClubs", "activeClubId", "settings"]);
  if (state[OWNER_EDITION_MIGRATION_KEY]) return;

  const legacyNames = new Set([
    "ACFA Official",
    "And Chess For All Official",
    "ACFA League",
    "ACFA San Antonio",
    "ACFA San Antonio TX",
    "The Haunted Rook"
  ]);
  const clubs = Array.isArray(state.managedClubs)
    ? state.managedClubs.filter((club) => !legacyNames.has(String(club?.name || "").trim()))
    : [];
  const settings = { ...DEFAULT_SETTINGS, ...(state.settings || {}) };
  if (legacyNames.has(String(settings.clubName || "").trim())) {
    Object.assign(settings, {
      setupComplete: false, clubName: "", clubUrl: "", homeClubSlug: "", messageClubSlug: "",
      websiteUrl: "", discordUrl: "", twitchUrl: "", customLogoData: ""
    });
  }
  await chrome.storage.local.set({
    managedClubs: clubs,
    activeClubId: clubs.some((club) => club.id === state.activeClubId) ? state.activeClubId : "",
    settings,
    [OWNER_EDITION_MIGRATION_KEY]: true
  });
}

export async function getSettings() {
  const savedData = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...(savedData.settings ?? {}) };
}
export async function saveSettings(settings) { await chrome.storage.local.set({ settings }); }
export async function resetSettings() { await chrome.storage.local.set({ settings: DEFAULT_SETTINGS }); return { ...DEFAULT_SETTINGS }; }
export { DEFAULT_SETTINGS };
